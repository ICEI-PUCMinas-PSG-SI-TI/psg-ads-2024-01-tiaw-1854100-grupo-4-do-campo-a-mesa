document.addEventListener('DOMContentLoaded', function() {
    if(localStorage.getItem('token') == null) {
        alert('Você precisa estar logado para acessar essa página');
        window.location.href = "./assets/html/login.html";
    }

    let userLogado = JSON.parse(localStorage.getItem('userLogado'));
    let logado = document.querySelector('#logado');
    if (logado) {
        logado.innerHTML = `Olá ${userLogado.nome}`;
    }
  
    function sair() {
        localStorage.removeItem('token');
        localStorage.removeItem('userLogado');
        window.location.href = "/assets/html/login.html";
    }

    // Adicionar evento de logout ao botão "Sair"
    const btnSair = document.getElementById('btnSair');
    if (btnSair) {
        btnSair.addEventListener('click', sair);
    }
});
